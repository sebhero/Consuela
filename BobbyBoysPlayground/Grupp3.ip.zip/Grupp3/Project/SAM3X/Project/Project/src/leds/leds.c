/*
 * leds.c
 *
 *  Author: viktor, erik, jelena, axel
 */ 
#include <asf.h>
#include "leds.h"

/**
 * \file
 *
 * \brief Helper function to cofigure a single pin/led
 *
 */
static void configure_led(ioport_pin_t pin) {
    ioport_set_pin_dir(pin, IOPORT_DIR_OUTPUT);
    ioport_set_pin_level(pin, IOPORT_PIN_LEVEL_LOW);
}    

void configure_leds() {
    
    configure_led(LED1);
    //configure_led(LED2);
    //configure_led(LED3);
    
}
