/*
 * console.h
 * 
 *  Author: viktor, erik, jelena, axel
 */ 


#ifndef CONSOLE_H_
#define CONSOLE_H_

void configure_console(void);


#endif /* CONSOLE_H_ */