
#ifndef CONSOLE_VIKTOR_H_
#define CONSOLE_VIKTOR_H_

#include <asf.h>
#include "config_viktor.h"

static void configure_console(void);


#endif /* CONSOLE_VIKTOR_H_ */