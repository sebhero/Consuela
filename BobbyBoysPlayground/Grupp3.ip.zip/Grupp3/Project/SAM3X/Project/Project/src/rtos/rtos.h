/*
 * rtos.h
 *
 *  Author: viktor, erik, jelena, axel
 */ 


#ifndef RTOS_H_
#define RTOS_H_

#define TSK_PRIO_BTN 2
static xTaskHandle task_ButtonPress;
static xTimerHandle timer_BlinkGreen;

void configure_rtos(void);


#endif /* RTOS_H_ */
