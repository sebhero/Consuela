 /*
 * buttons.h
 *
 *  Author: viktor, erik, jelena, axel
 */ 


#ifndef BUTTONS_H_
#define BUTTONS_H_

// Define which button is connected to which pin
#define BTN1 IOPORT_CREATE_PIN(PIOC, 24)
#define DOOR IOPORT_CREATE_PIN(PIOC, 23)
#define POOL IOPORT_CREATE_PIN(PIOC, 22)

//#define BTN2 IOPORT_CREATE_PIN(PIOC, 23)

/**
 * \file
 *
 * \brief Configure the pins connected to the buttons
 *
 */
void configure_buttons(void);


#endif /* BUTTONS_H_ */