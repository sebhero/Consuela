/*
 * indirections.h
 *
 *  Author: viktor, erik, jelena, axel
 */ 


#ifndef INDIRECTIONS_H_
#define INDIRECTIONS_H_

#include "leds/leds.h"
#include "buttons/buttons.h"


#define LED_GREEN LED1
//#define LED_YELLOW LED2
//#define LED_RED LED1

#define BUTTON_1 BTN1
//#define BUTTON_2 BTN2

extern volatile bool button_1_event;
extern volatile uint8_t button_1_reg[];
extern volatile uint8_t button_1_mem[];

extern volatile bool door_event;
extern volatile uint8_t door_reg[];
extern volatile uint8_t door_mem[];

extern volatile bool pool_event;
extern volatile uint8_t pool_reg[];
extern volatile uint8_t pool_mem[];



#endif /* INDIRECTIONS_H_ */