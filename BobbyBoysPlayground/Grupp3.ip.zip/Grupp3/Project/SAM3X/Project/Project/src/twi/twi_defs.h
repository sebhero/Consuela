/*
 * twi_defs.h
 *
 *  Author: viktor, erik, jelena, axel
 */ 


#ifndef TWI_DEFS_H_
#define TWI_DEFS_H_

uint8_t slave_access = 0;

#define tx_buffer_length 64
uint8_t tx_buffer[tx_buffer_length];
uint8_t tx_buffer_idx = 0;
uint8_t tx_event = 0;

#define rx_buffer_length 2
uint8_t rx_buffer[rx_buffer_length];
uint8_t rx_buffer_idx = 0;
uint8_t rx_event = 0;



#endif /* TWI_DEFS_H_ */