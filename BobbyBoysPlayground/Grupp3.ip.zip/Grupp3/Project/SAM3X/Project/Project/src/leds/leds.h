/*
 * leds.h
 *
 *  Author: viktor, erik, jelena, axel
 */ 


#ifndef LEDS_H_
#define LEDS_H_

// Define which led is connected to which pin
#define LED1 IOPORT_CREATE_PIN(PIOC, 25)
//#define LED2 IOPORT_CREATE_PIN(PIOC, 26)
//#define LED3 IOPORT_CREATE_PIN(PIOC, 25)

/**
 * \file
 *
 * \brief Configure the pins connected to the leds
 *
 */
void configure_leds(void);

#endif /* LEDS_H_ */