/*
 * rtos.c
 *
 *  Author: viktor, erik, jelena, axel
 */ 

#include <asf.h>
#include <indirections.h>
#include "rtos.h"

/**
 * \file
 *
 * \brief Task to move sensor data to "memory"
 *
 */
void vButtonPress(void *pvParameters) {
    while(1) {
        if(button_1_event) {
            button_1_event = 0;            
            button_1_mem[2] = 1u;           
        }
		if(door_event) {
			door_event = 0;
			door_mem[2] = 1u;			
			ioport_set_pin_level(LED_GREEN, door_mem[2]?1:0);
		}
		if(pool_event) {
			pool_event = 0;
			pool_mem[2] = 1u;
		}
    }
    vTaskDelete(task_ButtonPress);
}

void vBlinkGreen(xTimerHandle pxTimer) {
    ioport_toggle_pin_level(LED_GREEN);
}

void configure_rtos() {
        
    xTaskCreate(vButtonPress, "Button press", configMINIMAL_STACK_SIZE + 100, NULL, TSK_PRIO_BTN, &task_ButtonPress);
    //timer_BlinkGreen = xTimerCreate("Blink Green", 100, pdTRUE, 0, vBlinkGreen);
    //xTimerStart(timer_BlinkGreen, 0);
}
