
 /*
 * main.c
 *
 *  Author: viktor, erik, jelena, axel
 */ 

#include <asf.h>
#include "indirections.h"
#include "console/console.h"
#include "twi/twi.h"
#include "buttons/buttons.h"
#include "leds/leds.h"
#include "rtos/rtos.h"

volatile bool button_1_event = 0;
volatile uint8_t button_1_reg[] = {0xBE, 0xEF};
volatile uint8_t button_1_mem[] = {0,0,0,0};
	
volatile bool door_event = 0;
volatile uint8_t door_reg[] = {0xDE, 0xAD};
volatile uint8_t door_mem[] = {0,0,0,0};

volatile bool pool_event = 0;
volatile uint8_t pool_reg[] = {0xCA, 0xBE}; 
volatile uint8_t pool_mem[] = {0,0,0,0};

int main (void) {

    sysclk_init();

    board_init();

    //  Debug console
    configure_console();
    printf("Hello, world!\n");

    // External leds
    configure_leds();

    // External buttons
    configure_buttons();    
    
    // Always good with random number generation...
    //pmc_enable_periph_clk(ID_TRNG);
    //trng_enable(TRNG);
        
    // Two Wire Interface(TWI)/Inter IC Communication(I2C)
    configure_twi();
    
    // Real Time Operating System(RTOS)
    configure_rtos();
    vTaskStartScheduler();

    while(1) {
		// Should never get here
		// If we are here then FreeRTOS has stopped
		// Signal error
        delay_ms(500);  		       
		ioport_toggle_pin_level(LED_GREEN);     
    }   
    
    
}
