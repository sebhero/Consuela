/*
* twi.c
*
*  Author: viktor
*/

#include <asf.h>
#include <indirections.h>
#include "twi.h"

void configure_twi() {
    pmc_enable_periph_clk(ID_TWI1);
    twi_slave_init(TWI1, SLAVE_ADDRESS);
    twi_read_byte(TWI1);
    NVIC_DisableIRQ(TWI1_IRQn);
    NVIC_ClearPendingIRQ(TWI1_IRQn);
    NVIC_SetPriority(TWI1_IRQn, 0);
    NVIC_EnableIRQ(TWI1_IRQn);
    twi_enable_interrupt(TWI1, TWI_SR_SVACC);
}

void TWI1_Handler() {
    
    static uint8_t slave_access = 0;

    static uint8_t tx_buffer[64];
    static uint8_t tx_buffer_idx = 0;
    static uint8_t tx_event = 0;

    static uint8_t rx_buffer[2];
    static uint8_t rx_buffer_idx = 0;
    static uint8_t rx_event = 0;
    
    static uint32_t status = 0;
    status = twi_get_interrupt_status(TWI1);

    if(status & TWI_SR_SVACC) {
        // Slave access
        twi_disable_interrupt(TWI1, TWI_IDR_SVACC);
        twi_enable_interrupt(TWI1, TWI_IER_RXRDY | TWI_IER_NACK | TWI_IER_EOSACC | TWI_IER_SCL_WS);
        if(status & TWI_SR_GACC) {
            // General call, do not handle
        }
        else {
            if(status & TWI_SR_SVREAD) {
                // Slave read
                if(status & TWI_SR_TXRDY) {
                    // Last written byte has been sent
                    //twi_slave_write(TWI1, tx_buffer);
                    tx_event = 1;
                    twi_write_byte(TWI1,tx_buffer[tx_buffer_idx]);
                    printf("tx_buffer[%u] = %u\n", tx_buffer_idx, tx_buffer[tx_buffer_idx]);
                    ++tx_buffer_idx;
                    tx_buffer_idx = tx_buffer_idx % 4;
                }
                else {
                    // Nothing
                }
                
                
                
            }
            else {
                // Not slave read
                if(status & TWI_SR_RXRDY) {
                    // Byte in buffer
                    //twi_slave_read(TWI1, rx_buffer);
                    rx_event = 1;
                    rx_buffer[rx_buffer_idx] = twi_read_byte(TWI1);
                    //printf("rx_buffer[%u] = %u\n", rx_buffer_idx, rx_buffer[rx_buffer_idx]);
                    ++rx_buffer_idx;
                    if(rx_buffer_idx == 2u) {
                        tx_buffer[0] = rx_buffer[0];
                        tx_buffer[1] = rx_buffer[1];
                        tx_buffer[2] = button_1_mem[2]; //(uint8_t) (trng_read_output_data(TRNG) & 0XFF);
                        tx_buffer[3] = tx_buffer[0] ^ tx_buffer[1] ^ tx_buffer[2];
                    }
                    rx_buffer_idx = rx_buffer_idx % 2;

                }
                else {
                    // Nothing
                }
                
            }
        }
    }
    else {
        if(status & TWI_SR_EOSACC) {
            // End of slave access
            //printf("At loc. 1\n");
            if(status & TWI_SR_TXCOMP) {
                //printf("At loc. 2\n");
                // Transmission complete
                if(rx_event && (rx_buffer_idx == 0)) {
                    //printf("At loc. 3\n");
                    ioport_toggle_pin_level(LED_GREEN);
                    rx_event = 0;
                    printf("Got: %d %d\n", rx_buffer[0], rx_buffer[1]);
                }
                else if(tx_event && (tx_buffer_idx == 0)) {
                    //printf("At loc. 4\n");
                    tx_event = 0;
                    rx_buffer_idx = 0;
                    button_1_mem[2] = 0;
                }
                twi_enable_interrupt(TWI1, TWI_SR_SVACC);
                twi_disable_interrupt(TWI1,	TWI_IDR_RXRDY | TWI_IDR_GACC | TWI_IDR_NACK | TWI_IDR_EOSACC | TWI_IDR_SCL_WS);
            }
            else {
                // Nothing
            }
        }
        else {
            // Nothing
        }
    }
}