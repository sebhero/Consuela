/*
 * twi.h
 *
  *  Author: viktor, erik, jelena, axel
 */ 


#ifndef TWI_H_
#define TWI_H_


#define SLAVE_ADDRESS 0x4



void configure_twi(void);



#endif /* TWI_H_ */