

#include <asf.h>

#define LED_GREEN IOPORT_CREATE_PIN(PIOC, 25)
#define LED_YELLOW IOPORT_CREATE_PIN(PIOC, 26)
#define LED_RED IOPORT_CREATE_PIN(PIOC, 28)

#define BTN1 IOPORT_CREATE_PIN(PIOC, 24)
#define BTN2 IOPORT_CREATE_PIN(PIOC, 23)

xTaskHandle task_BlinkYellow;
xTimerHandle timer_BlinkGreen;

volatile bool doChangeLevel = 0;

void vBlinkYellow(void *pvParameters) {
    while(1) {
        if(doChangeLevel) {
            ioport_toggle_pin_level(LED_YELLOW); 
            doChangeLevel = 0;
        }
    }
    vTaskDelete(task_BlinkYellow);
}

void vBlinkGreen(xTimerHandle pxTimer) {
    ioport_toggle_pin_level(LED_GREEN); 
}

void btn1_handler(const uint32_t id, const uint32_t index) {
    if ((id == ID_PIOC) && (index == PIO_PC24)){
        doChangeLevel = 1;
    }
}

void configure_button(ioport_pin_t pin, void (*handler)(const uint32_t, const uint32_t)) {
    Pio *pio_base = arch_ioport_pin_to_base(pin);
    uint32_t pin_mask = arch_ioport_pin_to_mask(pin);
    IRQn_Type IRQn;
    uint32_t ID;
    switch(arch_ioport_pin_to_port_id(pin)) {
        case(IOPORT_PIOC):
        IRQn = PIOC_IRQn;
        ID = ID_PIOC;
        break;
    }
    
    pio_set_input(pio_base, pin_mask, PIO_PULLUP | PIO_DEBOUNCE);
    pio_handler_set(pio_base, ID, pin_mask, PIO_IT_FALL_EDGE, handler);
    pio_enable_interrupt(pio_base, pin_mask);
    NVIC_ClearPendingIRQ(IRQn);
    NVIC_EnableIRQ(IRQn);

}

void configure_leds() {       
    ioport_set_pin_dir(LED_RED, IOPORT_DIR_OUTPUT);
    ioport_set_pin_level(LED_RED, IOPORT_PIN_LEVEL_LOW);
    
    ioport_set_pin_dir(LED_GREEN, IOPORT_DIR_OUTPUT);
    ioport_set_pin_level(LED_GREEN, IOPORT_PIN_LEVEL_LOW);
    
    ioport_set_pin_dir(LED_YELLOW, IOPORT_DIR_OUTPUT);
    ioport_set_pin_level(LED_YELLOW, IOPORT_PIN_LEVEL_LOW);
}


int main (void)
{
	sysclk_init();

	board_init();
    
    configure_leds();
    
    configure_button(BTN1, btn1_handler);
    
    xTaskCreate(vBlinkYellow, "Blink yellow", configMINIMAL_STACK_SIZE + 100, NULL, 2, &task_BlinkYellow);
    timer_BlinkGreen = xTimerCreate("Blink Green", 100, pdTRUE, 0, vBlinkGreen);
    xTimerStart(timer_BlinkGreen, 0);
    vTaskStartScheduler();

	while(1) {        
        delay_ms(500);
        
        ioport_toggle_pin_level(LED_RED);  
    }
}
